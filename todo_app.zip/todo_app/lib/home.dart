import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart'
    hide EmailAuthProvider, PhoneAuthProvider;
import 'package:go_router/go_router.dart';
import 'authentication.dart';
import 'package:provider/provider.dart';
import 'models/note.dart';
import 'models/reminder.dart';


class NotaForm extends State<NotaFormState> {
  final titleController = TextEditingController();
  final descriptionController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Column(
        children: [
          TextField(
            controller: titleController,
            decoration: InputDecoration(
              border: OutlineInputBorder(),
              labelText: 'Titulo',
            ),
          ),
          const SizedBox(height: 10),
          TextField(
            controller: descriptionController,
            keyboardType: TextInputType.multiline,
            minLines: 1,
            //Normal textInputField will be displayed
            maxLines: 5,
            // when user presses enter it will adapt to it
            decoration: InputDecoration(
              border: OutlineInputBorder(),
              labelText: 'Descripcion',
            ),
          ),
          // button for confirm
          ButtonBar(
            children: [
              TextButton(
                onPressed: () {
                  Navigator.pop(context);
                },
                child: const Text('Cancelar'),
              ),
              TextButton(
                onPressed: () {
                  widget.callback(
                      titleController.text, descriptionController.text);
                  Navigator.pop(context);
                },
                child: const Text('Confirmar'),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class NotaFormState extends StatefulWidget {
  const NotaFormState({Key? key, required this.notes, required this.callback})
      : super(key: key);

  final List<Note> notes;
  final void Function(String, String) callback;

  @override
  NotaForm createState() => NotaForm();
}

class NotaEditFormState extends StatefulWidget {
  const NotaEditFormState(
      {Key? key,
        required this.notes,
        required this.callback,
        required this.deleteCallback,
        required this.title,
        required this.description})
      : super(key: key);

  final List<Note> notes;
  final void Function(String, String) callback;
  final void Function() deleteCallback;
  final String title;
  final String description;

  @override
  NotaEditForm createState() => NotaEditForm();
}

class NotaEditForm extends State<NotaEditFormState> {
  final titleController = TextEditingController();
  final descriptionController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    titleController.text = widget.title;
    descriptionController.text = widget.description;

    return Container(
      child: Column(
        children: [
          TextField(
            controller: titleController,
            decoration: InputDecoration(
              border: OutlineInputBorder(),
              labelText: 'Titulo',
            ),
          ),
          const SizedBox(height: 10),
          TextField(
            controller: descriptionController,
            keyboardType: TextInputType.multiline,
            minLines: 1,
            //Normal textInputField will be displayed
            maxLines: 5,
            // when user presses enter it will adapt to it
            decoration: InputDecoration(
              border: OutlineInputBorder(),
              labelText: 'Descripcion',
            ),
          ),
          // button for confirm
          ButtonBar(
            children: [
              TextButton(
                onPressed: () {
                  widget.deleteCallback();
                  Navigator.pop(context);
                },
                child: const Text('Eliminar'),
              ),
              TextButton(
                onPressed: () {
                  widget.callback(
                      titleController.text, descriptionController.text);
                  Navigator.pop(context);
                },
                child: const Text('Guardar'),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class ReminderFormState extends StatefulWidget {
  const ReminderFormState({Key? key, required this.callback})
      : super(key: key);

  final void Function(String, String, DateTime) callback;

  @override
  ReminderForm createState() => ReminderForm();
}

class ReminderForm extends State<ReminderFormState> {
  final titleController = TextEditingController();
  final descriptionController = TextEditingController();
  DateTime date = DateTime.now();

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          TextField(
            controller: titleController,
            decoration: InputDecoration(
              border: OutlineInputBorder(),
              labelText: 'Titulo',
            ),
          ),
          const SizedBox(height: 10),
          TextField(
            controller: descriptionController,
            keyboardType: TextInputType.multiline,
            minLines: 1,
            //Normal textInputField will be displayed
            maxLines: 5,
            // when user presses enter it will adapt to it
            decoration: InputDecoration(
              border: OutlineInputBorder(),
              labelText: 'Descripcion',
            ),
          ),
          const SizedBox(height: 10),
          // BUTTON FOR DATE INPUT
          TextButton(
              onPressed: () {
                showDatePicker(
                    context: context,
                    initialDate: DateTime.now(),
                    firstDate: DateTime.now(),
                    lastDate: DateTime(2101))
                    .then((value) => date = value!);
              },
              child: Text('Fecha')),
          ButtonBar(
            children: [
              TextButton(
                onPressed: () {
                  Navigator.pop(context);
                },
                child: const Text('Cancelar'),
              ),
              TextButton(
                onPressed: () {
                  widget.callback(
                      titleController.text, descriptionController.text, date);
                  Navigator.pop(context);
                },
                child: const Text('Confirmar'),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class ReminderEditFormState extends StatefulWidget {
  const ReminderEditFormState(
      {Key? key,
        required this.callback,
        required this.deleteCallback,
        required this.title,
        required this.description,
        required this.date})
      : super(key: key);

  final void Function(String, String, DateTime) callback;
  final void Function() deleteCallback;
  final String title;
  final String description;
  final DateTime date;

  @override
  ReminderEditForm createState() => ReminderEditForm();
}

class ReminderEditForm extends State<ReminderEditFormState> {
  final titleController = TextEditingController();
  final descriptionController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    titleController.text = widget.title;
    descriptionController.text = widget.description;
    DateTime date = widget.date;

    return Container(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          TextField(
            controller: titleController,
            decoration: InputDecoration(
              border: OutlineInputBorder(),
              labelText: 'Titulo',
            ),
          ),
          const SizedBox(height: 10),
          TextField(
            controller: descriptionController,
            keyboardType: TextInputType.multiline,
            minLines: 1,
            //Normal textInputField will be displayed
            maxLines: 5,
            // when user presses enter it will adapt to it
            decoration: InputDecoration(
              border: OutlineInputBorder(),
              labelText: 'Descripcion',
            ),
          ),
          const SizedBox(height: 10),
          TextButton(
              onPressed: () {
                showDatePicker(
                    context: context,
                    initialDate: widget.date,
                    firstDate: widget.date,
                    lastDate: DateTime(2101))
                    .then((value) => date = value!);
              },
              child: Text('Fecha')),
          ButtonBar(
            children: [
              TextButton(
                onPressed: () {
                  widget.deleteCallback();
                  Navigator.pop(context);
                },
                child: const Text('Eliminar'),
              ),
              TextButton(
                onPressed: () {
                  widget.callback(
                      titleController.text, descriptionController.text, date);
                  Navigator.pop(context);
                },
                child: const Text('Guardar'),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

const List<String> list = <String>['Todos','Mi día', 'Mi semana'];

class DropdownButtonExample extends StatefulWidget {
  const DropdownButtonExample({super.key});

  @override
  State<DropdownButtonExample> createState() => _DropdownButtonExampleState();
}

class _DropdownButtonExampleState extends State<DropdownButtonExample> {
  String dropdownValue = list.first;

  @override
  Widget build(BuildContext context) {
    return DropdownButton<String>(
      value: dropdownValue,
      icon: const Icon(Icons.arrow_downward),
      elevation: 16,
      style: const TextStyle(color: Colors.blue),
      underline: Container(
        height: 2,
        color: Colors.blue,
      ),
      onChanged: (String? value) {
        // This is called when the user selects an item.
        setState(() {
          dropdownValue = value!;
          print(dropdownValue);
          if(dropdownValue == "Mi día"){
            filterDay = true;
            filterWeek = false;
          }
          else if(dropdownValue == "Mi semana"){
            filterDay = false;
            filterWeek = true;
          }
          else{
            filterDay = false;
            filterWeek = false;
          }
        });
      },
      items: list.map<DropdownMenuItem<String>>((String value) {
        return DropdownMenuItem<String>(
          value: value,
          child: Text(value),
        );
      }).toList(),
    );
  }
}

bool filterWeek = false;
bool filterDay = false;

class HomePage extends StatefulWidget {
  HomePage({
    super.key,
    required this.loggedIn,
    required this.signOut,
  });

  final bool loggedIn;
  final void Function() signOut;
  final List<Note> notes = [];
  final List<Reminder> reminders = [];

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    Stream collectionStream =
    FirebaseFirestore.instance.collection('notes').snapshots();
    Stream remindersStream =
    FirebaseFirestore.instance.collection('reminders').snapshots();
    collectionStream.listen((event) {
      widget.notes.clear();
      List<Note> x = [];
      for (var i = 0; i < event.docs.length; i++) {
        var doc = event.docs[i].data();
        x.add(Note(
            id: event.docs[i].reference.id,
            title: doc['titulo'],
            description: doc['descripcion']));
      }
      widget.notes.addAll(x);
      setState(() {});
    });
    remindersStream.listen((event) {
      widget.reminders.clear();
      List<Reminder> x = [];
      for (var i = 0; i < event.docs.length; i++) {
        var doc = event.docs[i].data();
        if (filterWeek) {
          DateTime fecha = doc['fecha'].toDate();
          if (fecha.isAfter(DateTime.now()) &&
              fecha.isBefore(DateTime.now().add(Duration(
                  days: 7,
                  hours: DateTime.now().hour,
                  minutes: DateTime.now().minute)))) {
            x.add(Reminder(
                id: event.docs[i].reference.id,
                title: doc['titulo'],
                description: doc['descripcion'],
                date: doc['fecha'].toDate()));
          }
        } else if (filterDay) {
          DateTime fecha = doc['fecha'].toDate();
          if (fecha.day == DateTime.now().day &&
              fecha.month == DateTime.now().month &&
              fecha.year == DateTime.now().year) {
            x.add(Reminder(
                id: event.docs[i].reference.id,
                title: doc['titulo'],
                description: doc['descripcion'],
                date: doc['fecha'].toDate()));
          }
        } else {
          x.add(Reminder(
              id: event.docs[i].reference.id,
              title: doc['titulo'],
              description: doc['descripcion'],
              date: doc['fecha'].toDate()));
        }
      }
      widget.reminders.addAll(x);
      setState(() {});
    });
    if (widget.loggedIn) {
      return MaterialApp(
        home: DefaultTabController(
            length: 2,
            child: Builder(builder: (BuildContext context) {
              return Scaffold(
                floatingActionButton: FloatingActionButton(
                  onPressed: () {
                    final index = DefaultTabController.of(context).index;
                    if (index == 0) {
                      showDialog(
                          context: context,
                          builder: (BuildContext context) {
                            return SimpleDialog(
                              contentPadding: EdgeInsets.all(12.0),
                              title: const Text('Añadir Nota'),
                              children: [
                                NotaFormState(
                                    notes: widget.notes,
                                    callback: (a, b) {
                                      FirebaseFirestore.instance
                                          .collection('notes')
                                          .add({
                                        'titulo': a,
                                        'descripcion': b,
                                      });
                                      setState(() {});
                                    }),
                              ],
                            );
                          });
                    } else {
                      showDialog(
                          context: context,
                          builder: (BuildContext context) {
                            return SimpleDialog(
                              contentPadding: EdgeInsets.all(12.0),
                              title: const Text('Añadir Reminder'),
                              children: [
                                ReminderFormState(callback: (a, b, c) {
                                  FirebaseFirestore.instance
                                      .collection('reminders')
                                      .add({
                                    'titulo': a,
                                    'descripcion': b,
                                    'fecha': c,
                                  });
                                  setState(() {});
                                }),
                              ],
                            );
                          });
                    }
                  },
                  child: const Icon(Icons.add),
                ),
                appBar: AppBar(
                  bottom: const TabBar(
                    tabs: [
                      Tab(
                          child: Text(
                            "Notas",
                          )),
                      Tab(
                        child: Text(
                          "Reminders",
                        ),
                      ),
                    ],
                  ),
                ),
                body: TabBarView(
                  children: [
                    Column(children: [
                      Expanded(
                        child: ListView.builder(
                          // Let the ListView know how many items it needs to build.
                          itemCount: widget.notes.length,
                          // Provide a builder function. This is where the magic happens.
                          // Convert each item into a widget based on the type of item it is.
                          itemBuilder: (context, index) {
                            final item = widget.notes[index];
                            return ListTile(
                              onTap: () {
                                showDialog(
                                    context: context,
                                    builder: (BuildContext context) {
                                      return SimpleDialog(
                                        contentPadding: EdgeInsets.all(12.0),
                                        title: const Text('Editar Nota'),
                                        children: [
                                          NotaEditFormState(
                                            title: item.title,
                                            description: item.description,
                                            notes: widget.notes,
                                            callback: (a, b) {
                                              FirebaseFirestore.instance
                                                  .collection('notes')
                                                  .doc(widget.notes[index].id)
                                                  .update({
                                                'titulo': a,
                                                'descripcion': b,
                                              });
                                              setState(() {});
                                            },
                                            deleteCallback: () {
                                              FirebaseFirestore.instance
                                                  .collection('notes')
                                                  .doc(widget.notes[index].id)
                                                  .delete();
                                              setState(() {});
                                            },
                                          ),
                                        ],
                                      );
                                    });
                              },
                              title: Text(item.title),
                              subtitle: Text(item.description),
                            );
                          },
                        ),
                      )
                    ]),
                    Column(children: [
                      const SizedBox(height: 10),
                      Row(
                          children: [
                            Text('FIltros'),
                            DropdownButtonExample()
                          ]
                      ),
                      Expanded(
                        child: ListView.builder(
                          // Let the ListView know how many items it needs to build.
                          itemCount: widget.reminders.length,
                          // Provide a builder function. This is where the magic happens.
                          // Convert each item into a widget based on the type of item it is.
                          itemBuilder: (context, index) {
                            final item = widget.reminders[index];
                            return ListTile(
                              onTap: () {
                                showDialog(
                                    context: context,
                                    builder: (BuildContext context) {
                                      return SimpleDialog(
                                        contentPadding: EdgeInsets.all(12.0),
                                        title:
                                        const Text('Editar Reminder'),
                                        children: [
                                          ReminderEditFormState(
                                            title: item.title,
                                            description: item.description,
                                            date: item.date,
                                            callback: (a, b, c) {
                                              FirebaseFirestore.instance
                                                  .collection('reminders')
                                                  .doc(widget
                                                  .reminders[index].id)
                                                  .update({
                                                'titulo': a,
                                                'descripcion': b,
                                                'fecha': c,
                                              });
                                              setState(() {});
                                            },
                                            deleteCallback: () {
                                              FirebaseFirestore.instance
                                                  .collection('reminders')
                                                  .doc(widget
                                                  .reminders[index].id)
                                                  .delete();
                                              setState(() {});
                                            },
                                          ),
                                        ],
                                      );
                                    });
                              },
                              title: Text(item.title),
                              subtitle:
                              Text("${item.date}\n${item.description}"),
                            );
                          },
                        ),
                      )
                    ]),
                  ],
                ),
              );
            })),
      );
    } else {
      return const Authentication();
    }
  }
}
